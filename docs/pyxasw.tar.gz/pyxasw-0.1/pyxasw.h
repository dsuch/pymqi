/*
 * $Id: pyxasw.h,v 1.1 2003/02/07 17:06:14 lsmithso Exp $
 * pyxasw.h: pyxasw 'C' exported functions.
 *
 *
 * Author: L. Smithson (lsmithson@open-networks.co.uk)
 *
 * DISCLAIMER
 * You are free to use this code in any way you like, subject to the
 * Python disclaimers & copyrights. I make no representations about
 * the suitability of this software for any purpose. It is provided
 * "AS-IS" without warranty of any kind, either express or implied. So
 * there.
 */

#include "xa.h"

struct xa_switch_t *pyxasw_Wrapper(struct xa_switch_t *wrapee, char *modName);



